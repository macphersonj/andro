$( document ).ready(function() {
    console.log( "eSafety office JS loaded" );
});
